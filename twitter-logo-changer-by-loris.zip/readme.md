# Twitter Logo Changer

No more doge, Replace Twitter logo to classic.

We fucking hate the X logo, so get back to TWITTER OLD LOGO.